<?php

namespace Config;

use CodeIgniter\Config\BaseConfig;

class Email extends BaseConfig
{
    public string $fromEmail  = 'no-reply@lms.fernandesraymond.id';
    public string $fromName   = 'LMS Elecomp';
    public string $recipients = '';
    public string $userAgent = 'CodeIgniter';
    public string $protocol = 'smtp';
    public string $mailPath = '/usr/sbin/sendmail';
    
    public string $SMTPHost       = 'mail.fernandesraymond.id';
    public string $SMTPAuthMethod = 'login';
    public string $SMTPUser       = 'no-reply@lms.fernandesraymond.id';
    public string $SMTPPass       = 'Tb=xFoMN@iXC!3_)';
    public int    $SMTPPort       = 465;
    public int    $SMTPTimeout    = 60;
    public bool   $SMTPKeepAlive  = false;
    public string $SMTPCrypto     = 'ssl';
    
    public bool   $wordWrap    = true;
    public int    $wrapChars   = 76;
    public string $mailType    = 'html';
    public string $charset     = 'UTF-8';
    public bool   $validate    = true;
    public int    $priority    = 3;
    public string $CRLF        = "\r\n";
    public string $newline     = "\r\n";
    public bool   $BCCBatchMode = false;
    public int    $BCCBatchSize = 200;
    public bool   $DSN         = false;
}